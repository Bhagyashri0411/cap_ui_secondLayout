export function getData() {
    return [
      {
        department: "Govern (GV)",
        quality: 40,
        efficiency: 75,
      },
      {
        department: "Identity (ID)",
        quality: 45,
        efficiency: 90,
      },
      {
        department: "Protect (PR)",
        quality: 80,
        efficiency: 60,
      },
      {
        department: "Detect (DE)",
        quality: 80,
        efficiency: 60,
      },
      {
        department: "Respond (RS)",
        quality: 85,
        efficiency: 50,
      },
      {
        department: "Recover (RC)",
        quality: 90,
        efficiency: 50,
      },
    
    ];
  }
  