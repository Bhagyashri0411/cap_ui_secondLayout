import { Component, ElementRef } from '@angular/core';
import { getData } from './data';
import "ag-charts-enterprise";

@Component({
  selector: 'app-cyber-chart',
  templateUrl: './cyber-chart.component.html',
  styleUrls: ['./cyber-chart.component.scss']
})
export class CyberChartComponent {
  public options;

  constructor() {
    this.options = {
      data: getData(),

      
      
      series: [
        {
          type: "radar-line",
          angleKey: "department",
          radiusKey: "quality",
          radiusName: "Quality",
          strokeWidth: 1,
          marker: {
            enabled: false,
          },
          stroke: "green"
        },
        {
          type: "radar-line",
          angleKey: "department",
          radiusKey: "efficiency",
          radiusName: "Efficiency",
          lineDash: [4],
          strokeWidth: 1,
          marker: {
            enabled: false
          },
        },
      ],
      
      axes: [
        {
          type: "angle-category",
          gridLine: {
            enabled: false,
          },
          label: {
            fontSize: 8,
            padding: 0,
            fontWeight:700
          },
        },
        {
          type: "radius-number",
          gridLine: {
            enabled: true,
          },
          line: {
            enabled: false,
          },
          label: {
            enabled: false,
          },
        },
      ],
      
      legend: {
        enabled: false
      }
    };
  }
}
